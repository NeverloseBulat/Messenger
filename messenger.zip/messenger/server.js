'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { WebSocketServer } = require('ws');

const PORT = process.env.PORT || 3000;
// Путь к файлу с данными можно задать переменной DATA_FILE (например, на подключённом диске хостинга)
const DATA_FILE = process.env.DATA_FILE || path.join(__dirname, 'data.json');
const PUBLIC_DIR = path.join(__dirname, 'public');

const MAX_TEXT = 4000;
const HISTORY_LIMIT = 500;

// ---------------------------------------------------------------- storage --

let db = { users: {}, chats: {}, sessions: {} };
if (fs.existsSync(DATA_FILE)) {
  try {
    db = Object.assign(db, JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')));
  } catch (e) {
    console.error('Не удалось прочитать data.json, начинаем с пустой базы:', e.message);
  }
}

let saveTimer = null;
function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    const tmp = DATA_FILE + '.tmp';
    fs.writeFile(tmp, JSON.stringify(db), (err) => {
      if (err) return console.error('Ошибка сохранения:', err.message);
      fs.rename(tmp, DATA_FILE, () => {});
    });
  }, 200);
}

// ------------------------------------------------------------------- auth --

function hashPassword(password, salt) {
  return crypto.scryptSync(password, salt, 64).toString('hex');
}

function checkPassword(user, password) {
  const a = Buffer.from(hashPassword(password, user.salt), 'hex');
  const b = Buffer.from(user.hash, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function newToken(username) {
  const token = crypto.randomBytes(32).toString('hex');
  db.sessions[token] = username;
  save();
  return token;
}

const USERNAME_RE = /^[a-z0-9_]{3,20}$/;

// ---------------------------------------------------------------- clients --

const clients = new Map(); // username -> Set<ws>

function isOnline(username) {
  const set = clients.get(username);
  return !!set && set.size > 0;
}

function sendTo(username, payload) {
  const set = clients.get(username);
  if (!set) return;
  const data = JSON.stringify(payload);
  for (const ws of set) {
    if (ws.readyState === 1) ws.send(data);
  }
}

function sendWs(ws, payload) {
  if (ws.readyState === 1) ws.send(JSON.stringify(payload));
}

function broadcastAll(payload) {
  for (const username of clients.keys()) sendTo(username, payload);
}

// ------------------------------------------------------------------ chats --

function dmId(a, b) {
  return 'dm:' + [a, b].sort().join(':');
}

function newId() {
  return crypto.randomBytes(8).toString('hex');
}

function getOrCreateDm(a, b) {
  const id = dmId(a, b);
  if (!db.chats[id]) {
    db.chats[id] = { id, type: 'dm', name: '', members: [a, b], messages: [], reads: { [a]: 0, [b]: 0 } };
    save();
  }
  return db.chats[id];
}

function chatView(chat, user) {
  const last = chat.messages.length ? chat.messages[chat.messages.length - 1] : null;
  const reads = chat.reads[user] || 0;
  const view = {
    id: chat.id,
    type: chat.type,
    members: chat.members,
    reads: chat.reads,
    total: chat.messages.length,
    unread: Math.max(0, chat.messages.length - reads),
    last: last ? { from: last.from, text: last.text, ts: last.ts, system: !!last.system } : null,
  };
  if (chat.type === 'dm') {
    const peer = chat.members.find((m) => m !== user) || user;
    view.name = peer;
    view.peer = peer;
    view.lastSeen = (db.users[peer] && db.users[peer].lastSeen) || null;
  } else {
    view.name = chat.name;
    view.owner = chat.owner;
  }
  return view;
}

function chatsFor(user) {
  return Object.values(db.chats)
    .filter((c) => c.members.includes(user) && (c.type === 'group' || c.messages.length > 0))
    .map((c) => chatView(c, user));
}

function pushMessage(chat, message) {
  chat.messages.push(message);
  if (chat.messages.length > HISTORY_LIMIT) {
    const drop = chat.messages.length - HISTORY_LIMIT;
    chat.messages.splice(0, drop);
    for (const m of chat.members) chat.reads[m] = Math.max(0, (chat.reads[m] || 0) - drop);
  }
  save();
  for (const member of chat.members) {
    sendTo(member, { type: 'message', chatId: chat.id, message, chat: chatView(chat, member) });
  }
}

function markRead(chat, user) {
  if ((chat.reads[user] || 0) === chat.messages.length) return false;
  chat.reads[user] = chat.messages.length;
  save();
  for (const member of chat.members) {
    sendTo(member, { type: 'reads', chatId: chat.id, reads: chat.reads });
  }
  return true;
}

// --------------------------------------------------------------- handlers --

function authOk(ws, username, token) {
  ws.user = username;
  if (!clients.has(username)) clients.set(username, new Set());
  const wasOnline = isOnline(username);
  clients.get(username).add(ws);
  sendWs(ws, {
    type: 'auth_ok',
    username,
    token,
    chats: chatsFor(username),
    online: [...clients.keys()].filter(isOnline),
  });
  if (!wasOnline) broadcastAll({ type: 'presence', user: username, online: true });
}

function handle(ws, m) {
  if (!m || typeof m !== 'object') return;

  // ---- unauthenticated
  if (m.type === 'register') {
    const username = String(m.username || '').trim().toLowerCase();
    const password = String(m.password || '');
    if (!USERNAME_RE.test(username)) {
      return sendWs(ws, { type: 'auth_error', error: 'Имя: 3–20 символов, латиница, цифры и _' });
    }
    if (password.length < 6) {
      return sendWs(ws, { type: 'auth_error', error: 'Пароль должен быть не короче 6 символов' });
    }
    if (db.users[username]) {
      return sendWs(ws, { type: 'auth_error', error: 'Это имя уже занято' });
    }
    const salt = crypto.randomBytes(16).toString('hex');
    db.users[username] = { salt, hash: hashPassword(password, salt), created: Date.now(), lastSeen: null };
    save();
    return authOk(ws, username, newToken(username));
  }

  if (m.type === 'login') {
    const username = String(m.username || '').trim().toLowerCase();
    const user = db.users[username];
    if (!user || !checkPassword(user, String(m.password || ''))) {
      return sendWs(ws, { type: 'auth_error', error: 'Неверное имя или пароль' });
    }
    return authOk(ws, username, newToken(username));
  }

  if (m.type === 'resume') {
    const username = db.sessions[String(m.token || '')];
    if (!username || !db.users[username]) {
      return sendWs(ws, { type: 'auth_error', error: 'Сессия истекла, войдите заново', resume: true });
    }
    return authOk(ws, username, m.token);
  }

  // ---- authenticated
  const me = ws.user;
  if (!me) return;

  switch (m.type) {
    case 'search': {
      const q = String(m.query || '').trim().toLowerCase();
      const users = Object.keys(db.users)
        .filter((u) => u !== me && (q === '' || u.includes(q)))
        .slice(0, 20)
        .map((u) => ({ username: u, online: isOnline(u) }));
      return sendWs(ws, { type: 'search_result', query: q, ctx: m.ctx || null, users });
    }

    case 'open_dm': {
      const peer = String(m.username || '').toLowerCase();
      if (!db.users[peer] || peer === me) return sendWs(ws, { type: 'error', error: 'Пользователь не найден' });
      const chat = getOrCreateDm(me, peer);
      return sendWs(ws, { type: 'chat_open', chat: chatView(chat, me) });
    }

    case 'create_group': {
      const name = String(m.name || '').trim().slice(0, 50);
      if (!name) return sendWs(ws, { type: 'error', error: 'Введите название группы' });
      const members = [...new Set([me, ...(Array.isArray(m.members) ? m.members : [])])]
        .map((u) => String(u).toLowerCase())
        .filter((u) => db.users[u]);
      if (members.length < 2) return sendWs(ws, { type: 'error', error: 'Добавьте хотя бы одного участника' });
      const id = 'g:' + newId();
      const chat = { id, type: 'group', name, owner: me, members, messages: [], reads: {} };
      for (const u of members) chat.reads[u] = 0;
      db.chats[id] = chat;
      pushMessage(chat, { id: newId(), from: me, text: `${me} создал(а) группу «${name}»`, ts: Date.now(), system: true });
      return sendWs(ws, { type: 'chat_open', chat: chatView(chat, me) });
    }

    case 'history': {
      const chat = db.chats[m.chatId];
      if (!chat || !chat.members.includes(me)) return;
      return sendWs(ws, { type: 'history', chatId: chat.id, messages: chat.messages, reads: chat.reads });
    }

    case 'send': {
      const text = String(m.text || '').trim().slice(0, MAX_TEXT);
      if (!text) return;
      const chat = db.chats[m.chatId];
      if (!chat || !chat.members.includes(me)) return;
      pushMessage(chat, { id: newId(), from: me, text, ts: Date.now() });
      // отправитель, очевидно, прочитал всё в чате
      markRead(chat, me);
      return;
    }

    case 'read': {
      const chat = db.chats[m.chatId];
      if (!chat || !chat.members.includes(me)) return;
      return void markRead(chat, me);
    }

    case 'typing': {
      const chat = db.chats[m.chatId];
      if (!chat || !chat.members.includes(me)) return;
      for (const member of chat.members) {
        if (member !== me) sendTo(member, { type: 'typing', chatId: chat.id, user: me });
      }
      return;
    }

    case 'logout': {
      if (m.token) delete db.sessions[m.token];
      save();
      return;
    }
  }
}

// ------------------------------------------------------------ http server --

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
};

const server = http.createServer((req, res) => {
  let urlPath;
  try {
    urlPath = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
  } catch {
    res.writeHead(400);
    return res.end('Bad request');
  }
  if (urlPath === '/') urlPath = '/index.html';
  const filePath = path.normalize(path.join(PUBLIC_DIR, urlPath));
  if (!filePath.startsWith(PUBLIC_DIR + path.sep)) {
    res.writeHead(403);
    return res.end('Forbidden');
  }
  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end('Не найдено');
    }
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(filePath)] || 'application/octet-stream',
      'Cache-Control': 'no-cache',
    });
    res.end(data);
  });
});

const wss = new WebSocketServer({ server, maxPayload: 64 * 1024 });

wss.on('connection', (ws) => {
  ws.user = null;
  ws.isAlive = true;
  ws.on('pong', () => (ws.isAlive = true));
  ws.on('message', (raw) => {
    let m;
    try {
      m = JSON.parse(raw);
    } catch {
      return;
    }
    try {
      handle(ws, m);
    } catch (e) {
      console.error('Ошибка обработки сообщения:', e);
    }
  });
  ws.on('close', () => {
    const me = ws.user;
    if (!me) return;
    const set = clients.get(me);
    if (set) {
      set.delete(ws);
      if (set.size === 0) {
        clients.delete(me);
        const lastSeen = Date.now();
        if (db.users[me]) db.users[me].lastSeen = lastSeen;
        save();
        broadcastAll({ type: 'presence', user: me, online: false, lastSeen });
      }
    }
  });
});

// отбрасываем «мёртвые» соединения
setInterval(() => {
  for (const ws of wss.clients) {
    if (!ws.isAlive) {
      ws.terminate();
      continue;
    }
    ws.isAlive = false;
    ws.ping();
  }
}, 30000);

server.listen(PORT, () => {
  console.log(`Мессенджер запущен: http://localhost:${PORT}`);
});

function shutdown() {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(db));
  } catch {}
  process.exit(0);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
