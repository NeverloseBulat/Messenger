'use strict';

const $ = (sel) => document.querySelector(sel);

// ------------------------------------------------------------- состояние --

const state = {
  me: null,
  token: localStorage.getItem('token'),
  chats: new Map(),   // id -> chatView
  msgs: new Map(),    // id -> [message]
  online: new Set(),
  active: null,
  typing: {},         // chatId -> { user -> timeoutId }
  people: [],         // результаты поиска людей в боковой панели
  groupMembers: new Set(),
  mode: 'login',
};

let ws = null;
let reconnectTimer = null;

// -------------------------------------------------------------- утилиты --

function send(obj) {
  if (ws && ws.readyState === 1) ws.send(JSON.stringify(obj));
}

function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text !== undefined) e.textContent = text;
  return e;
}

function colorFor(name) {
  let h = 0;
  for (const ch of name) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return `hsl(${h % 360}, 55%, 45%)`;
}

function makeAvatar(target, name, group, online) {
  target.textContent = group ? '👥' : (name[0] || '?');
  target.style.background = group ? '#6b7c85' : colorFor(name);
  target.classList.toggle('online', !!online);
}

const pad = (n) => String(n).padStart(2, '0');

function hhmm(ts) {
  const d = new Date(ts);
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function sameDay(a, b) {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

function listTime(ts) {
  const d = new Date(ts);
  const now = new Date();
  if (sameDay(d, now)) return hhmm(ts);
  const y = new Date(now);
  y.setDate(now.getDate() - 1);
  if (sameDay(d, y)) return 'вчера';
  return `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${String(d.getFullYear()).slice(2)}`;
}

function dayLabel(ts) {
  const d = new Date(ts);
  const now = new Date();
  if (sameDay(d, now)) return 'Сегодня';
  const y = new Date(now);
  y.setDate(now.getDate() - 1);
  if (sameDay(d, y)) return 'Вчера';
  return d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: d.getFullYear() === now.getFullYear() ? undefined : 'numeric' });
}

function lastSeenText(ts) {
  if (!ts) return 'не в сети';
  const d = new Date(ts);
  if (sameDay(d, new Date())) return `был(а) в сети в ${hhmm(ts)}`;
  return `был(а) в сети ${listTime(ts)}`;
}

function toast(text) {
  const t = $('#toast');
  t.textContent = text;
  t.classList.remove('hidden');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => t.classList.add('hidden'), 3000);
}

function setConn(ok) {
  const c = $('#conn');
  c.textContent = ok ? 'в сети' : 'нет соединения…';
  c.classList.toggle('bad', !ok);
}

// ----------------------------------------------------------- соединение --

function connect() {
  clearTimeout(reconnectTimer);
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  ws = new WebSocket(`${proto}://${location.host}`);

  ws.onopen = () => {
    if (state.token) send({ type: 'resume', token: state.token });
    else showAuth();
  };
  ws.onmessage = (e) => {
    let m;
    try { m = JSON.parse(e.data); } catch { return; }
    onServer(m);
  };
  ws.onclose = () => {
    setConn(false);
    reconnectTimer = setTimeout(connect, 1500);
  };
  ws.onerror = () => ws.close();
}

// ------------------------------------------------------ сообщения сервера --

function onServer(m) {
  switch (m.type) {
    case 'auth_ok': {
      state.me = m.username;
      state.token = m.token;
      localStorage.setItem('token', m.token);
      state.online = new Set(m.online);
      state.chats = new Map(m.chats.map((c) => [c.id, c]));
      showApp();
      setConn(true);
      renderList();
      if (state.active && state.chats.has(state.active)) send({ type: 'history', chatId: state.active });
      break;
    }
    case 'auth_error': {
      if (m.resume) {
        state.token = null;
        localStorage.removeItem('token');
        showAuth();
      } else {
        $('#auth-error').textContent = m.error;
      }
      break;
    }
    case 'chat_open': {
      state.chats.set(m.chat.id, Object.assign(state.chats.get(m.chat.id) || {}, m.chat));
      $('#search').value = '';
      state.people = [];
      closeModal();
      openChat(m.chat.id);
      break;
    }
    case 'history': {
      state.msgs.set(m.chatId, m.messages);
      const chat = state.chats.get(m.chatId);
      if (chat) chat.reads = m.reads;
      if (state.active === m.chatId) {
        renderMessages();
        markReadIfVisible();
      }
      break;
    }
    case 'message': {
      state.chats.set(m.chatId, m.chat);
      if (state.msgs.has(m.chatId)) state.msgs.get(m.chatId).push(m.message);
      // собеседник перестал печатать
      clearTyping(m.chatId, m.message.from);
      if (state.active === m.chatId) {
        renderMessages(m.message.from === state.me);
        markReadIfVisible();
        // локально считаем прочитанным
        m.chat.unread = document.hidden ? m.chat.unread : 0;
      }
      renderList();
      updateTitle();
      break;
    }
    case 'reads': {
      const chat = state.chats.get(m.chatId);
      if (chat) {
        chat.reads = m.reads;
        chat.unread = Math.max(0, chat.total - (m.reads[state.me] || 0));
      }
      if (state.active === m.chatId) renderMessages(false, true);
      renderList();
      updateTitle();
      break;
    }
    case 'presence': {
      if (m.online) state.online.add(m.user);
      else state.online.delete(m.user);
      for (const c of state.chats.values()) {
        if (c.type === 'dm' && c.peer === m.user && m.lastSeen) c.lastSeen = m.lastSeen;
      }
      renderList();
      if (state.active) renderHeader();
      break;
    }
    case 'typing': {
      setTyping(m.chatId, m.user);
      break;
    }
    case 'search_result': {
      if (m.ctx === 'group') renderGroupResults(m.users);
      else if (m.query === $('#search').value.trim().toLowerCase()) {
        state.people = m.users;
        renderList();
      }
      break;
    }
    case 'error': {
      if (!$('#modal').classList.contains('hidden')) $('#group-error').textContent = m.error;
      else toast(m.error);
      break;
    }
  }
}

// -------------------------------------------------------------- экраны --

function showAuth() {
  $('#app').classList.add('hidden');
  $('#auth').classList.remove('hidden');
  $('#auth-user').focus();
}

function showApp() {
  $('#auth').classList.add('hidden');
  $('#app').classList.remove('hidden');
  $('#me-name').textContent = state.me;
  makeAvatar($('#me-avatar'), state.me, false, false);
  $('#auth-error').textContent = '';
  $('#auth-pass').value = '';
}

// --------------------------------------------------------------- вход --

document.querySelectorAll('.tab').forEach((tab) => {
  tab.addEventListener('click', () => {
    state.mode = tab.dataset.mode;
    document.querySelectorAll('.tab').forEach((t) => t.classList.toggle('active', t === tab));
    $('#auth-submit').textContent = state.mode === 'login' ? 'Войти' : 'Создать аккаунт';
    $('#auth-pass').autocomplete = state.mode === 'login' ? 'current-password' : 'new-password';
    $('#auth-error').textContent = '';
  });
});

$('#auth-form').addEventListener('submit', (e) => {
  e.preventDefault();
  $('#auth-error').textContent = '';
  send({
    type: state.mode,
    username: $('#auth-user').value,
    password: $('#auth-pass').value,
  });
});

$('#btn-logout').addEventListener('click', () => {
  send({ type: 'logout', token: state.token });
  localStorage.removeItem('token');
  state.token = null;
  location.reload();
});

// ----------------------------------------------------- список чатов --

function previewText(c) {
  if (!c.last) return c.type === 'group' ? 'Группа создана' : '';
  const typing = typingUsers(c.id);
  if (typing.length) return c.type === 'group' ? `${typing.join(', ')} печатает…` : 'печатает…';
  if (c.last.system) return c.last.text;
  const who = c.last.from === state.me ? 'Вы: ' : c.type === 'group' ? c.last.from + ': ' : '';
  return who + c.last.text.replace(/\s+/g, ' ');
}

function renderList() {
  const list = $('#chat-list');
  const q = $('#search').value.trim().toLowerCase();
  list.textContent = '';

  const chats = [...state.chats.values()]
    .filter((c) => !q || c.name.toLowerCase().includes(q))
    .sort((a, b) => ((b.last && b.last.ts) || 0) - ((a.last && a.last.ts) || 0));

  for (const c of chats) {
    const item = el('div', 'chat-item' + (c.id === state.active ? ' active' : ''));
    const av = el('div', 'avatar');
    makeAvatar(av, c.name, c.type === 'group', c.type === 'dm' && state.online.has(c.peer));
    const body = el('div', 'ci-body');
    const top = el('div', 'ci-top');
    top.append(el('div', 'ci-name', c.name));
    if (c.last) top.append(el('div', 'ci-time' + (c.unread ? ' unread' : ''), listTime(c.last.ts)));
    const bottom = el('div', 'ci-bottom');
    const last = el('div', 'ci-last', previewText(c));
    if (typingUsers(c.id).length) last.style.color = 'var(--accent)';
    bottom.append(last);
    if (c.unread && c.id !== state.active) bottom.append(el('div', 'badge', c.unread > 99 ? '99+' : String(c.unread)));
    body.append(top, bottom);
    item.append(av, body);
    item.addEventListener('click', () => openChat(c.id));
    list.append(item);
  }

  if (q) {
    const existing = new Set([...state.chats.values()].filter((c) => c.type === 'dm').map((c) => c.peer));
    const people = state.people.filter((p) => !existing.has(p.username));
    if (people.length) {
      list.append(el('div', 'section-label', 'Люди'));
      for (const p of people) {
        const item = el('div', 'chat-item');
        const av = el('div', 'avatar');
        makeAvatar(av, p.username, false, state.online.has(p.username));
        const body = el('div', 'ci-body');
        const top = el('div', 'ci-top');
        top.append(el('div', 'ci-name', p.username));
        const bottom = el('div', 'ci-bottom');
        bottom.append(el('div', 'ci-last', 'Начать переписку'));
        body.append(top, bottom);
        item.append(av, body);
        item.addEventListener('click', () => send({ type: 'open_dm', username: p.username }));
        list.append(item);
      }
    }
  }

  if (!list.children.length) {
    list.append(el('div', 'list-empty', q ? 'Ничего не найдено' : 'Пока нет чатов. Найдите человека через поиск или создайте группу 👥'));
  }
}

let searchTimer = null;
$('#search').addEventListener('input', () => {
  const q = $('#search').value.trim().toLowerCase();
  renderList();
  clearTimeout(searchTimer);
  if (!q) { state.people = []; return; }
  searchTimer = setTimeout(() => send({ type: 'search', query: q }), 200);
});

// ------------------------------------------------------------ окно чата --

function openChat(id) {
  state.active = id;
  $('#empty').classList.add('hidden');
  $('#chat').classList.remove('hidden');
  $('#app').classList.add('in-chat');
  renderHeader();
  renderMessages(true);
  renderList();
  send({ type: 'history', chatId: id });
  $('#input').focus({ preventScroll: true });
}

$('#btn-back').addEventListener('click', () => {
  state.active = null;
  $('#app').classList.remove('in-chat');
  renderList();
});

function renderHeader() {
  const c = state.chats.get(state.active);
  if (!c) return;
  makeAvatar($('#chat-avatar'), c.name, c.type === 'group', c.type === 'dm' && state.online.has(c.peer));
  $('#chat-title').textContent = c.name;
  const sub = $('#chat-sub');
  const typing = typingUsers(c.id);
  sub.classList.toggle('typing', typing.length > 0);
  if (typing.length) {
    sub.textContent = c.type === 'group' ? `${typing.join(', ')} печатает…` : 'печатает…';
  } else if (c.type === 'dm') {
    sub.textContent = state.online.has(c.peer) ? 'в сети' : lastSeenText(c.lastSeen);
  } else {
    sub.textContent = `${c.members.length} участн.: ${c.members.join(', ')}`;
  }
}

function isDelivered(chat, msg, index) {
  // прочитано всеми остальными участниками?
  return chat.members.filter((m) => m !== msg.from).every((m) => (chat.reads[m] || 0) > index);
}

function renderMessages(forceScroll, keepScroll) {
  const box = $('#messages');
  const chat = state.chats.get(state.active);
  if (!chat) return;
  const list = state.msgs.get(state.active) || [];
  const nearBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 120;
  const prevTop = box.scrollTop;
  box.textContent = '';

  let lastDay = null;
  let prev = null;
  list.forEach((msg, i) => {
    const d = new Date(msg.ts);
    const label = dayLabel(msg.ts);
    if (label !== lastDay) {
      box.append(el('div', 'day', label));
      lastDay = label;
      prev = null;
    }
    if (msg.system) {
      box.append(el('div', 'sys', msg.text));
      prev = null;
      return;
    }
    const out = msg.from === state.me;
    const b = el('div', 'msg' + (out ? ' out' : '') + (!prev || prev.from !== msg.from ? ' first' : ''));
    if (chat.type === 'group' && !out && (!prev || prev.from !== msg.from)) {
      const f = el('div', 'from', msg.from);
      f.style.color = colorFor(msg.from);
      b.append(f);
    }
    b.append(document.createTextNode(msg.text));
    const meta = el('span', 'meta');
    meta.append(document.createTextNode(hhmm(msg.ts)));
    if (out) {
      const read = isDelivered(chat, msg, i);
      meta.append(el('span', 'tick' + (read ? ' read' : ''), '✓✓'));
    }
    b.append(meta);
    box.append(b);
    prev = msg;
  });

  if (forceScroll || nearBottom) box.scrollTop = box.scrollHeight;
  else if (keepScroll) box.scrollTop = prevTop;
}

function markReadIfVisible() {
  const c = state.chats.get(state.active);
  if (!c || document.hidden) return;
  if (c.unread > 0 || (c.reads[state.me] || 0) < c.total) {
    c.unread = 0;
    send({ type: 'read', chatId: c.id });
    renderList();
    updateTitle();
  }
}

document.addEventListener('visibilitychange', () => {
  if (!document.hidden) markReadIfVisible();
});

function updateTitle() {
  let total = 0;
  for (const c of state.chats.values()) total += c.unread || 0;
  document.title = total ? `(${total}) Мессенджер` : 'Мессенджер';
}

// ------------------------------------------------------------- «печатает» --

function typingUsers(chatId) {
  return Object.keys(state.typing[chatId] || {});
}

function setTyping(chatId, user) {
  const t = (state.typing[chatId] = state.typing[chatId] || {});
  clearTimeout(t[user]);
  t[user] = setTimeout(() => clearTyping(chatId, user), 3500);
  refreshTyping(chatId);
}

function clearTyping(chatId, user) {
  const t = state.typing[chatId];
  if (!t || !(user in t)) return;
  clearTimeout(t[user]);
  delete t[user];
  refreshTyping(chatId);
}

function refreshTyping(chatId) {
  renderList();
  if (state.active === chatId) renderHeader();
}

// -------------------------------------------------------------- отправка --

const input = $('#input');
let lastTypingSent = 0;

function autosize() {
  input.style.height = 'auto';
  input.style.height = Math.min(input.scrollHeight, 140) + 'px';
}

input.addEventListener('input', () => {
  autosize();
  const now = Date.now();
  if (state.active && input.value && now - lastTypingSent > 2000) {
    lastTypingSent = now;
    send({ type: 'typing', chatId: state.active });
  }
});

input.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
    e.preventDefault();
    $('#composer').requestSubmit();
  }
});

$('#composer').addEventListener('submit', (e) => {
  e.preventDefault();
  const text = input.value.trim();
  if (!text || !state.active) return;
  send({ type: 'send', chatId: state.active, text });
  input.value = '';
  autosize();
  input.focus();
});

// ----------------------------------------------------------------- группа --

function openModal() {
  state.groupMembers = new Set();
  $('#group-name').value = '';
  $('#group-search').value = '';
  $('#group-error').textContent = '';
  renderChips();
  $('#group-results').textContent = '';
  $('#modal').classList.remove('hidden');
  $('#group-name').focus();
  send({ type: 'search', query: '', ctx: 'group' });
}

function closeModal() {
  $('#modal').classList.add('hidden');
}

function renderChips() {
  const box = $('#group-chips');
  box.textContent = '';
  for (const u of state.groupMembers) {
    const chip = el('div', 'chip', u);
    const x = el('button', null, '×');
    x.type = 'button';
    x.addEventListener('click', () => {
      state.groupMembers.delete(u);
      renderChips();
      send({ type: 'search', query: $('#group-search').value.trim().toLowerCase(), ctx: 'group' });
    });
    chip.append(x);
    box.append(chip);
  }
}

function renderGroupResults(users) {
  const box = $('#group-results');
  box.textContent = '';
  const rows = users.filter((u) => !state.groupMembers.has(u.username));
  if (!rows.length) box.append(el('div', 'list-empty', 'Никого не найдено'));
  for (const u of rows) {
    const item = el('div', 'chat-item');
    const av = el('div', 'avatar');
    makeAvatar(av, u.username, false, state.online.has(u.username));
    const body = el('div', 'ci-body');
    body.append(el('div', 'ci-name', u.username));
    item.append(av, body);
    item.addEventListener('click', () => {
      state.groupMembers.add(u.username);
      renderChips();
      renderGroupResults(users);
    });
    box.append(item);
  }
}

let groupSearchTimer = null;
$('#group-search').addEventListener('input', () => {
  clearTimeout(groupSearchTimer);
  groupSearchTimer = setTimeout(
    () => send({ type: 'search', query: $('#group-search').value.trim().toLowerCase(), ctx: 'group' }),
    200
  );
});

$('#btn-group').addEventListener('click', openModal);
$('#group-cancel').addEventListener('click', closeModal);
$('#modal').addEventListener('click', (e) => { if (e.target === $('#modal')) closeModal(); });
$('#group-create').addEventListener('click', () => {
  $('#group-error').textContent = '';
  send({ type: 'create_group', name: $('#group-name').value, members: [...state.groupMembers] });
});

// ------------------------------------------------------------------ старт --

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));
}

connect();
